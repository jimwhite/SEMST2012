==================================================
*SEM SHARED TASK 2012 
http://www.clips.ua.ac.be/sem2012-st-neg/
TRAINING AND DEVELOPMENT FILES FOR TASK 1 ON SCOPE DETECTION
==================================================


Dataset  CD-SCO for Task 1
-----------------------

SEM-2012-SharedTask-CD-SCO-training.txt: training file that contains the The Hound of the Baskervilles by Conan Doyle.

SEM-2012-SharedTask-CD-SCO-dev.txt: development file that contains the The Adventures of Wisteria Lodge by Conan Doyle.

Annotation
---------

All occurrences of a negation are annotated, accounting for negation expressed by nouns, pronouns, verbs, adverbs, determiners, conjunctions and prepositions. For each negation cue, the negation cue and scope are marked, as well as the negated event or property, if any. Cues and scopes can be discontinuous. 

More information about the annotation can be found in the annotation guidelines, which  are published in Morante et al. (2011) Annotation of Negation Cues and their Scope. Guidelines v1.0, CLiPS Technical Report Series, to be downloaded from:

http://www.clips.ua.ac.be/annotation-of-negation-cues-and-their-scope-guidelines-v10

Format
------

The data are provided in CoNLL format. Each line corresponds to a token and each annotation (chunks, named entities, etc.) is provided in a column; empty lines indicate end of sentence. The content of the columns is specified below.

Tokenization and information for columns 4 to 7 has been obtained by processing the corpus with the Shalmaneser (Erk and Padó, 2006) semantic parser. Shalmaneser produces  the xml-format needed to annotate the corpus with negation with the Salto Tool (Burchardt et al., 2006). The xml was converted into CoNLL format.  Shalmaneser calls the Collins parser (Collins, 1997) to produce syntactic parse trees.  


Column 1: chapter name

Column 2: sentence number within chapter

Column 3: token number within sentence

Column 4: word

Column 5: lemma

Column 6: part-of-speech

Column 7: syntax

Columns 8 to last: (to be produced by the systems, will not be provided in test data)

       - If the sentence has no negations,  column 8 has a "***" value and there are no more columns.
       - If the sentence has negations, the annotation for each negation is provided in three columns. The first column contains the word or part of the word (e.g., morpheme "un"), that belongs to the negation cue. The second contains the word or part of the word that belongs to the scope of the negation cue. The third column contains the word or part of the word that is the negated event or property. It can be the case that no negated event or property are marked as negated. For example, in Example 3 none of the negations has a negated event annotated because of the conditional construction.

In Example 1 there are two negations. Information for the first negation is provided in columns 8-10, and for the second in columns 11-13. Example 2 shows how prefixal negation is represented. "un" is the negation cue, "conventional appearance" is the scope, and "conventional" is the negated property.


Example 1

Wisteria_ch1	287	0	He	he	PRP	(S*	_	He	_	_	He	_
Wisteria_ch1	287	1	is	be	VBZ	(VP*	_	is	_	_	is	_
Wisteria_ch1	287	2	not	not	RB	*	not	_	_	_	_	_
Wisteria_ch1	287	3	particularly	particularly	RB	*	_	particularly	_	_	_	_
Wisteria_ch1	287	4	intelligent	intelligent	JJ	(NPB*	_	intelligent	intelligent	_	_	_
Wisteria_ch1	287	5	-	-	PUNC:	*	_	_	_	_	_	_
Wisteria_ch1	287	6	-	-	PUNC:	*	_	_	_	_	_	_
Wisteria_ch1	287	7	not	not	RB	*	_	_	_	not	_	_
Wisteria_ch1	287	8	a	a	DT	*	_	_	_	_	a	_
Wisteria_ch1	287	9	man	man	NN	*NPB)	_	_	_	_	man	_
Wisteria_ch1	287	10	likely	likely	JJ	(ADJP*	_	_	_	_	likely	likely
Wisteria_ch1	287	11	to	to	TO	(VP*	_	_	_	_	to	_
Wisteria_ch1	287	12	be	be	VB	(VP*	_	_	_	_	be	_
Wisteria_ch1	287	13	congenial	congenial	JJ	(ADJP*	_	_	_	_	congenial	_
Wisteria_ch1	287	14	to	to	TO	(PP*	_	_	_	_	to	_
Wisteria_ch1	287	15	a	a	DT	(NPB*	_	_	_	_	a	_
Wisteria_ch1	287	16	quick-witted	quick-witted	JJ	*	_	_	_	_	quick-witted	_
Wisteria_ch1	287	17	Latin	Latin	NNP	*	_	_	_	_	Latin	_
Wisteria_ch1	287	18	.	.	PUNC.	*NPB)PP)ADJP)VP)VP)ADJP)VP)S)	_	_	_	_	_	_

Example 2

Wisteria_ch1	60	0	Our	our	PRP$	(S(NPB*	_	_	_
Wisteria_ch1	60	1	client	client	NN	*NPB)	_	_	_
Wisteria_ch1	60	2	looked	look	VBD	(VP*	_	_	_
Wisteria_ch1	60	3	down	down	RB	*	_	_	_
Wisteria_ch1	60	4	with	with	IN	(PP*	_	_	_
Wisteria_ch1	60	5	a	a	DT	(NPB*	_	_	_
Wisteria_ch1	60	6	rueful	rueful	JJ	*	_	_	_
Wisteria_ch1	60	7	face	face	NN	*NPB)PP)	_	_	_
Wisteria_ch1	60	8	at	at	IN	(PP*	_	_	_
Wisteria_ch1	60	9	his	his	PRP$	(NPB*	_	his	_
Wisteria_ch1	60	10	own	own	JJ	*	_	own	_
Wisteria_ch1	60	11	unconventional	unconventional	JJ	*	un	conventional	conventional
Wisteria_ch1	60	12	appearance	appearance	NN	*	_	appearance	_
Wisteria_ch1	60	13	.	.	PUNC.	*NPB)PP)VP)S)	_	_	_

Example 3

Wisteria_ch1	319	0	She	she	PRP	(S*	_	She	_	_	_	_
Wisteria_ch1	319	1	would	would	MD	(VP*	_	would	_	_	_	_
Wisteria_ch1	319	2	not	not	RB	*	not	_	_	_	_	_
Wisteria_ch1	319	3	have	have	VB	(VP*	_	have	_	_	_	_
Wisteria_ch1	319	4	said	say	VBD	(VP*	_	said	_	_	_	_
Wisteria_ch1	319	5	'	'	POS	(SINV(NP*	_	'	_	_	_	_
Wisteria_ch1	319	6	Godspeed	godspeed	NN	*	_	Godspeed	_	_	_	_
Wisteria_ch1	319	7	'	'	PUNC''	*NP)	_	'	_	_	_	_
Wisteria_ch1	319	8	had	have	VBD	*	_	had	_	_	had	_
Wisteria_ch1	319	9	it	it	PRP	*	_	it	_	_	it	_
Wisteria_ch1	319	10	not	not	RB	*	_	not	_	not	_	_
Wisteria_ch1	319	11	been	be	VBN	(VP*	_	been	_	_	been	_
Wisteria_ch1	319	12	so	so	RB	(ADVP*	_	so	_	_	so	_
Wisteria_ch1	319	13	.	.	PUNC.	*ADVP)VP)SINV)VP)VP)VP)S)	_	_	_	_	_	_


Credits
--------

This corpus has been compiled and annotated with negation at CLiPS, Univesity of Antwerp (www.clips.ua.ac.be), with funding  from  the GOA project BIOGRAPH of the University of Antwerp. Processing with the Shalmaneser tool was performed at Saarland University. We are grateful to Josef Ruppenhofer for that. Chapters 12, 13 and 14 of the Hound of the Baskervilles and Chapter 2 of The Adventure of Wisteria Lodge was initially annotated at Saarland University  with information about predicate argument structure (FrameNet and PropBank), null instantiations, and coreference for the SemEval 2010 Task-10 on “Linking Events and Their Participants in Discourse” (Ruppenhofer et al. 2010).


Comments and errors
-----------------

If you find errors and inconsistencies in the dataset, please report them to Roser Morante (roser.morante@ua.ac.be). 
We welcome also comments on the annotation guidelines. 


References
---------

A. Burchardt, K. Erk, A. Frank, A. Kowalski, and Sebastian Padó. Salto - a versatile multi-level annotation tool. In In Proceedings of LREC 2006, 2006.

M. Collins. Three generative, lexicalised models for statistical parsing. In Proceedings of ACL/EACL 1997, pages 16–23, 1997.

K. Erk and S. Padó. Shalmaneser - a flexible toolbox for semantic role assignment. In Proceedings of LREC-06, 2006.

R. Morante, S. Schrauwen, and W. Daelemans. Annotation of negation cues and their scope guidelines v1.0. Technical Report CTR-003, CLiPS, University of Antwerp, Antwerp, 2011.

J. Ruppenhofer, C. Sporleder, R. Morante, C. Baker, and M. Palmer. Semeval-2010 task 10: Linking events and their participants in discourse. In The NAACLHLT2009 Workshop on Semantic Evaluations: Recent Achievements and Future Directions (SEW-09), 2009.
